SAS3IRCU
========
This is a Userworld Tool (SAS3IRCU) for RAID configuration on LSI SAS3 Controllers that is designed to run from a host.
Phase 16 GCA Release Version 17.00.00.00
Release Date : 01-Aug-19
Package contains binaries for DOS, Windows x86/x64, Linux x86/x64/PPC64, EFI, FreeBSD i386/amd64, Solaris x86/SPARC.
Release Notes: IRCU_MPT_GEN3_C0_16-17.00.00.00.pdf
